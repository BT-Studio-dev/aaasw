# BT Panel

BT Panel is an independent, self-hosted control-panel application with a BT-branded interface and workflows inspired by common Pterodactyl panel patterns. It is not an official Pterodactyl distribution, and this project does not bundle Pterodactyl source code. See [Pterodactyl Panel](https://github.com/pterodactyl/panel) for the upstream project.

## Requirements

- Node.js 22 LTS
- npm
- A MySQL-compatible database

## Local development

1. Copy `.env.example` to `.env`.
2. Set `APP_ID`, `APP_SECRET`, and `DATABASE_URL` in `.env`.
3. Install dependencies with `npm ci`.
4. Start the development server with `npm run dev`.

The Vite development server runs on port `3000` by default.

## Production

```sh
npm ci
npm run check
npm run build
NODE_ENV=production npm start
```

Set the required environment variables in the production environment before starting the server. The frontend is built to `dist/public`, and the bundled API server is written to `dist/boot.js`.

## Project checks

- `npm run check` runs TypeScript project checks.
- `npm run lint` runs ESLint.
- `npm test` runs Vitest tests.
- `npm run build` builds the frontend and bundles the API server.

## Integration scope

BT Panel currently provides its own panel UI and records. Creating a server record does not provision or control a live game server; real console, power, file, and resource operations require a Pterodactyl/Wings integration.
